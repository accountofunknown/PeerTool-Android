# PeerTool ProGuard rules (debug builds do not minify)
-keepattributes *Annotation*
-keep class creator.peer.tool.** { *; }
