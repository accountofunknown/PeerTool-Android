package creator.peer.tool.transport

import android.content.Context
import android.util.Log
import creator.peer.tool.crypto.IdentityManager
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.nio.charset.StandardCharsets

/**
 * WebRTC data-channel transport scaffold.
 *
 * Full native WebRTC (org.webrtc:google-webrtc) requires:
 * - A signaling channel (WebSocket / HTTP) to exchange SDP offers/answers and ICE candidates
 * - STUN (and optionally TURN) servers
 *
 * This class implements the MessagingTransport contract and a minimal in-process
 * signaling stub so the rest of the app can route through it. For real multi-device
 * internet P2P you must:
 * 1. Add dependency: implementation("io.getstream:stream-webrtc-android:1.1.1")
 *    or the official Google WebRTC AAR
 * 2. Host or use a signaling server (see SIGNALING_URL constant)
 * 3. Complete PeerConnectionFactory + DataChannel wiring in connect()/send()
 *
 * Until then, send() returns false and connection states stay DISCONNECTED
 * unless a local loopback is used for testing.
 */
class WebRtcTransport(
    private val context: Context,
    private val identity: IdentityManager
) : MessagingTransport {

    override val type = TransportType.WEBRTC

    private val _states = MutableStateFlow<Map<String, String>>(emptyMap())
    override val connectionStates: StateFlow<Map<String, String>> = _states.asStateFlow()

    private val _incoming = MutableSharedFlow<IncomingEnvelope>(extraBufferCapacity = 64)
    override val incoming: SharedFlow<IncomingEnvelope> = _incoming.asSharedFlow()

    /** Optional public STUN; replace with your own TURN for production. */
    val iceServers = listOf(
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302"
    )

    /**
     * Placeholder signaling endpoint. Set to your server, e.g.
     * wss://signal.example.com/peertool
     */
    var signalingUrl: String? = null

    override suspend fun start() {
        Log.i(TAG, "WebRTC transport ready (signaling=${signalingUrl ?: "none – offline mode"})")
    }

    override suspend fun stop() {
        _states.value = emptyMap()
    }

    override suspend fun connect(peerId: String) {
        setState(peerId, "CONNECTING")
        // Real implementation: create PeerConnection, create offer, send via signaling
        if (signalingUrl.isNullOrBlank()) {
            setState(peerId, "FAILED")
            Log.w(TAG, "No signaling URL configured – cannot establish WebRTC")
            return
        }
        // Scaffold only
        setState(peerId, "FAILED")
    }

    override suspend fun disconnect(peerId: String) {
        setState(peerId, "DISCONNECTED")
    }

    override suspend fun send(peerId: String, messageId: String, payload: ByteArray): Boolean {
        if (!isConnected(peerId)) return false
        // Real: dataChannel.send(DataChannel.Buffer(...))
        return false
    }

    override fun isConnected(peerId: String): Boolean =
        _states.value[peerId] == "CONNECTED"

    /** Inject a locally simulated incoming message (for unit tests / demos). */
    suspend fun injectIncoming(from: String, messageId: String, body: ByteArray) {
        _incoming.emit(IncomingEnvelope(from, messageId, body, TransportType.WEBRTC))
    }

    private fun setState(peerId: String, state: String) {
        _states.value = _states.value + (peerId to state)
    }

    companion object {
        private const val TAG = "WebRtcTransport"
    }
}
