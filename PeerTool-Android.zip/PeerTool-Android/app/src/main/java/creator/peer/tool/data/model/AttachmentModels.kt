package creator.peer.tool.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class AttachmentStatus {
    PENDING, ENCRYPTING, TRANSFERRING, COMPLETE, FAILED, CANCELLED
}

@Entity(tableName = "attachments")
data class AttachmentEntity(
    @PrimaryKey val attachmentId: String = UUID.randomUUID().toString(),
    val messageId: String,
    val peerId: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val localPath: String?,
    val status: String = AttachmentStatus.PENDING.name,
    val progress: Float = 0f,
    val isOutgoing: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
