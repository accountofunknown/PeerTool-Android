package creator.peer.tool.transport

import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

enum class TransportType {
    NEARBY, WEBRTC, LOCAL_DEMO
}

data class IncomingEnvelope(
    val fromPeerId: String,
    val messageId: String,
    val payload: ByteArray,
    val transport: TransportType
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is IncomingEnvelope) return false
        return messageId == other.messageId
    }
    override fun hashCode(): Int = messageId.hashCode()
}

interface MessagingTransport {
    val type: TransportType
    val connectionStates: StateFlow<Map<String, String>>
    val incoming: SharedFlow<IncomingEnvelope>

    suspend fun start()
    suspend fun stop()
    suspend fun connect(peerId: String)
    suspend fun disconnect(peerId: String)
    suspend fun send(peerId: String, messageId: String, payload: ByteArray): Boolean
    fun isConnected(peerId: String): Boolean
}
