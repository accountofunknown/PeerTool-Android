package creator.peer.tool.transport

import android.content.Context
import android.util.Log
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import creator.peer.tool.crypto.IdentityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.nio.charset.StandardCharsets

/**
 * Real Nearby Connections transport (Wi-Fi / Bluetooth, offline capable).
 * Service ID is fixed so peers find each other. Endpoint name = peerId.
 *
 * Requires runtime permissions (Bluetooth, Nearby Wi-Fi, location on older APIs).
 * Strategy: P2P_STAR for phone-to-phone messaging.
 */
class NearbyTransport(
    private val context: Context,
    private val identity: IdentityManager
) : MessagingTransport {

    override val type = TransportType.NEARBY

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val client: ConnectionsClient = Nearby.getConnectionsClient(context)

    private val _states = MutableStateFlow<Map<String, String>>(emptyMap())
    override val connectionStates: StateFlow<Map<String, String>> = _states.asStateFlow()

    private val _incoming = MutableSharedFlow<IncomingEnvelope>(extraBufferCapacity = 64)
    override val incoming: SharedFlow<IncomingEnvelope> = _incoming.asSharedFlow()

    /** endpointId → peerId */
    private val endpointToPeer = mutableMapOf<String, String>()
    /** peerId → endpointId */
    private val peerToEndpoint = mutableMapOf<String, String>()

    private val serviceId = "creator.peer.tool.nearby"
    @Volatile private var running = false
    fun isRunning(): Boolean = running

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = payload.asBytes() ?: return
            scope.launch {
                try {
                    val json = JSONObject(String(bytes, StandardCharsets.UTF_8))
                    val from = json.getString("from")
                    val mid = json.getString("id")
                    val bodyB64 = json.getString("body")
                    val body = android.util.Base64.decode(bodyB64, android.util.Base64.NO_WRAP)
                    _incoming.emit(
                        IncomingEnvelope(from, mid, body, TransportType.NEARBY)
                    )
                } catch (e: Exception) {
                    Log.w(TAG, "Bad payload", e)
                }
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private val connectionLifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            // Auto-accept for same service; production should show verification UI
            client.acceptConnection(endpointId, payloadCallback)
            val peerId = info.endpointName
            endpointToPeer[endpointId] = peerId
            peerToEndpoint[peerId] = endpointId
            setState(peerId, "CONNECTING")
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            val peerId = endpointToPeer[endpointId] ?: return
            if (result.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                setState(peerId, "CONNECTED")
            } else {
                setState(peerId, "FAILED")
                endpointToPeer.remove(endpointId)
                peerToEndpoint.remove(peerId)
            }
        }

        override fun onDisconnected(endpointId: String) {
            val peerId = endpointToPeer.remove(endpointId)
            if (peerId != null) {
                peerToEndpoint.remove(peerId)
                setState(peerId, "DISCONNECTED")
            }
        }
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val peerId = info.endpointName
            if (peerId == identity.peerId) return
            endpointToPeer[endpointId] = peerId
            setState(peerId, "DISCOVERED")
            // Auto-request connection
            scope.launch {
                try {
                    client.requestConnection(identity.peerId, endpointId, connectionLifecycle).await()
                } catch (e: Exception) {
                    Log.w(TAG, "requestConnection failed", e)
                    setState(peerId, "FAILED")
                }
            }
        }

        override fun onEndpointLost(endpointId: String) {
            val peerId = endpointToPeer.remove(endpointId)
            if (peerId != null) {
                peerToEndpoint.remove(peerId)
                setState(peerId, "DISCONNECTED")
            }
        }
    }

    override suspend fun start() {
        val advOptions = AdvertisingOptions.Builder()
            .setStrategy(Strategy.P2P_STAR)
            .build()
        val discOptions = DiscoveryOptions.Builder()
            .setStrategy(Strategy.P2P_STAR)
            .build()
        try {
            client.startAdvertising(
                identity.peerId,
                serviceId,
                connectionLifecycle,
                advOptions
            ).await()
            client.startDiscovery(serviceId, discoveryCallback, discOptions).await()
            running = true
            Log.i(TAG, "Nearby advertising + discovery started as ${identity.peerId}")
        } catch (e: Exception) {
            Log.e(TAG, "Nearby start failed – check permissions", e)
        }
    }

    override suspend fun stop() {
        client.stopAllEndpoints()
        client.stopAdvertising()
        client.stopDiscovery()
        endpointToPeer.clear()
        peerToEndpoint.clear()
        _states.value = emptyMap()
        running = false
    }

    override suspend fun connect(peerId: String) {
        // Discovery already requests connection when endpoint is found
    }

    override suspend fun disconnect(peerId: String) {
        val ep = peerToEndpoint[peerId] ?: return
        client.disconnectFromEndpoint(ep)
        peerToEndpoint.remove(peerId)
        endpointToPeer.entries.removeAll { it.value == peerId }
        setState(peerId, "DISCONNECTED")
    }

    override suspend fun send(peerId: String, messageId: String, payload: ByteArray): Boolean {
        val ep = peerToEndpoint[peerId] ?: return false
        return try {
            val json = JSONObject()
                .put("from", identity.peerId)
                .put("id", messageId)
                .put("body", android.util.Base64.encodeToString(payload, android.util.Base64.NO_WRAP))
            val bytes = json.toString().toByteArray(StandardCharsets.UTF_8)
            client.sendPayload(ep, Payload.fromBytes(bytes)).await()
            true
        } catch (e: Exception) {
            Log.w(TAG, "send failed", e)
            false
        }
    }

    override fun isConnected(peerId: String): Boolean =
        _states.value[peerId] == "CONNECTED"

    private fun setState(peerId: String, state: String) {
        _states.value = _states.value + (peerId to state)
    }

    companion object {
        private const val TAG = "NearbyTransport"
    }
}
