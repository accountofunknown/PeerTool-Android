package creator.peer.tool.util

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import org.json.JSONObject

object QrUtils {

    fun encodePeerPayload(peerId: String, displayName: String, publicKeyB64: String?): String {
        return JSONObject()
            .put("v", 1)
            .put("id", peerId)
            .put("name", displayName)
            .put("pk", publicKeyB64 ?: "")
            .toString()
    }

    fun decodePeerPayload(raw: String): Triple<String, String, String?>? {
        return try {
            val o = JSONObject(raw)
            val id = o.getString("id")
            val name = o.optString("name", id.take(8))
            val pk = o.optString("pk").ifBlank { null }
            Triple(id, name, pk)
        } catch (e: Exception) {
            // plain peer id
            if (raw.isNotBlank() && raw.length in 8..64) Triple(raw.trim(), raw.take(8), null)
            else null
        }
    }

    fun toBitmap(content: String, size: Int = 512): Bitmap {
        val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) {
            for (y in 0 until size) {
                bmp.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
            }
        }
        return bmp
    }

    fun decodeFromBitmap(bitmap: Bitmap): String? {
        return try {
            val w = bitmap.width
            val h = bitmap.height
            val pixels = IntArray(w * h)
            bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
            val source = RGBLuminanceSource(w, h, pixels)
            val binary = BinaryBitmap(HybridBinarizer(source))
            MultiFormatReader().decode(binary).text
        } catch (e: Exception) {
            null
        }
    }
}
