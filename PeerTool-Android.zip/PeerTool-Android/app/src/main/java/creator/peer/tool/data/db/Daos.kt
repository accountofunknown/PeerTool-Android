package creator.peer.tool.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import creator.peer.tool.data.model.ConversationEntity
import creator.peer.tool.data.model.MessageEntity
import creator.peer.tool.data.model.OutboxEntity
import creator.peer.tool.data.model.PeerEntity
import creator.peer.tool.data.model.ProcessedIdEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PeerDao {
    @Query("SELECT * FROM peers WHERE isBlocked = 0 ORDER BY displayName ASC")
    fun observePeers(): Flow<List<PeerEntity>>

    @Query("SELECT * FROM peers WHERE peerId = :peerId LIMIT 1")
    suspend fun getPeer(peerId: String): PeerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(peer: PeerEntity)

    @Update
    suspend fun update(peer: PeerEntity)

    @Query("UPDATE peers SET connectionState = :state, activeTransport = :transport WHERE peerId = :peerId")
    suspend fun updateConnection(peerId: String, state: String, transport: String?)

    @Query("DELETE FROM peers WHERE peerId = :peerId")
    suspend fun delete(peerId: String)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY lastMessageAt DESC")
    fun observeConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE peerId = :peerId LIMIT 1")
    suspend fun getByPeer(peerId: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(conversation: ConversationEntity)

    @Query("UPDATE conversations SET lastMessagePreview = :preview, lastMessageAt = :at, unreadCount = unreadCount + :inc WHERE conversationId = :id")
    suspend fun updateLastMessage(id: String, preview: String, at: Long, inc: Int)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC")
    fun observeMessages(conversationId: String): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: MessageEntity)

    @Query("UPDATE messages SET status = :status, deliveredAt = :deliveredAt WHERE messageId = :messageId")
    suspend fun updateStatus(messageId: String, status: String, deliveredAt: Long? = null)

    @Query("SELECT * FROM messages WHERE messageId = :messageId LIMIT 1")
    suspend fun getById(messageId: String): MessageEntity?
}

@Dao
interface OutboxDao {
    @Query("SELECT * FROM outbox ORDER BY nextAttemptAt ASC")
    suspend fun getPending(): List<OutboxEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(job: OutboxEntity)

    @Query("DELETE FROM outbox WHERE jobId = :jobId")
    suspend fun delete(jobId: String)

    @Query("UPDATE outbox SET attempts = attempts + 1, nextAttemptAt = :next WHERE jobId = :jobId")
    suspend fun markAttempt(jobId: String, next: Long)
}

@Dao
interface ProcessedDao {
    @Query("SELECT COUNT(*) FROM processed_ids WHERE messageId = :messageId")
    suspend fun exists(messageId: String): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(id: ProcessedIdEntity)
}
