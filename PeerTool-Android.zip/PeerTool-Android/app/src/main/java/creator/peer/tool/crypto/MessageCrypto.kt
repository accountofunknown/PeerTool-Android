package creator.peer.tool.crypto

import android.content.Context
import android.util.Base64
import com.google.crypto.tink.Aead
import com.google.crypto.tink.KeyTemplates
import com.google.crypto.tink.KeysetHandle
import com.google.crypto.tink.aead.AeadConfig
import com.google.crypto.tink.integration.android.AndroidKeysetManager
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Payload encryption for messages and attachments.
 *
 * - Local device keyset stored via Tink AndroidKeysetManager (Android Keystore backed).
 * - Peer-to-peer: ECDH (secp256r1) shared secret → AES-256-GCM for the envelope body.
 * - This is NOT a full Signal/MLS ratchet; it provides authenticated encryption
 *   of message bodies once peer public keys are known and verified.
 */
class MessageCrypto(context: Context) {

    private val aead: Aead

    init {
        AeadConfig.register()
        val handle = AndroidKeysetManager.Builder()
            .withSharedPref(context, KEYSET_NAME, PREF_FILE)
            .withKeyTemplate(KeyTemplates.get("AES256_GCM"))
            .withMasterKeyUri(MASTER_KEY_URI)
            .build()
            .keysetHandle
        aead = handle.getPrimitive(Aead::class.java)
    }

    /** Encrypt for local storage / attachment files. */
    fun encryptLocal(plaintext: ByteArray, associatedData: ByteArray = ByteArray(0)): ByteArray {
        return aead.encrypt(plaintext, associatedData)
    }

    fun decryptLocal(ciphertext: ByteArray, associatedData: ByteArray = ByteArray(0)): ByteArray {
        return aead.decrypt(ciphertext, associatedData)
    }

    fun encryptLocalString(text: String): String {
        val ct = encryptLocal(text.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(ct, Base64.NO_WRAP)
    }

    fun decryptLocalString(encoded: String): String {
        val ct = Base64.decode(encoded, Base64.NO_WRAP)
        return String(decryptLocal(ct), StandardCharsets.UTF_8)
    }

    /**
     * Derive a shared AES key from our private key and peer public key (ECDH).
     * Returns null if keys are incompatible.
     */
    fun deriveSharedKey(ourPrivate: java.security.PrivateKey, peerPublicBytes: ByteArray): SecretKey? {
        return try {
            val kf = java.security.KeyFactory.getInstance("EC")
            val peerPub = kf.generatePublic(java.security.spec.X509EncodedKeySpec(peerPublicBytes))
            val ka = KeyAgreement.getInstance("ECDH")
            ka.init(ourPrivate)
            ka.doPhase(peerPub, true)
            val shared = ka.generateSecret()
            val digest = MessageDigest.getInstance("SHA-256").digest(shared)
            SecretKeySpec(digest, "AES")
        } catch (e: Exception) {
            null
        }
    }

    /** Encrypt message body with peer shared key (AES-GCM). */
    fun encryptForPeer(key: SecretKey, plaintext: ByteArray): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val ct = cipher.doFinal(plaintext)
        return iv + ct
    }

    fun decryptFromPeer(key: SecretKey, blob: ByteArray): ByteArray {
        require(blob.size > 12) { "ciphertext too short" }
        val iv = blob.copyOfRange(0, 12)
        val ct = blob.copyOfRange(12, blob.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return cipher.doFinal(ct)
    }

    companion object {
        private const val KEYSET_NAME = "peertool_aead"
        private const val PREF_FILE = "peertool_tink"
        private const val MASTER_KEY_URI = "android-keystore://peertool_master"
    }
}
