package creator.peer.tool.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class ConnectionState {
    DISCOVERED, CONNECTING, CONNECTED, DEGRADED, RECONNECTING, DISCONNECTED, FAILED
}

enum class MessageStatus {
    QUEUED, SENDING, SENT, DELIVERED, READ, FAILED, EXPIRED
}

@Entity(tableName = "peers")
data class PeerEntity(
    @PrimaryKey val peerId: String,
    val displayName: String,
    val publicKeyPem: String? = null,
    val isTrusted: Boolean = false,
    val isBlocked: Boolean = false,
    val lastSeen: Long = 0L,
    val connectionState: String = ConnectionState.DISCONNECTED.name,
    val activeTransport: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val conversationId: String = UUID.randomUUID().toString(),
    val peerId: String,
    val lastMessagePreview: String = "",
    val lastMessageAt: Long = 0L,
    val unreadCount: Int = 0,
    val isMuted: Boolean = false
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val messageId: String = UUID.randomUUID().toString(),
    val conversationId: String,
    val peerId: String,
    val isOutgoing: Boolean,
    val body: String,
    val status: String = MessageStatus.QUEUED.name,
    val createdAt: Long = System.currentTimeMillis(),
    val deliveredAt: Long? = null,
    val readAt: Long? = null,
    val replyToId: String? = null,
    val attachmentPath: String? = null
)

@Entity(tableName = "outbox")
data class OutboxEntity(
    @PrimaryKey val jobId: String = UUID.randomUUID().toString(),
    val messageId: String,
    val peerId: String,
    val payload: String,
    val attempts: Int = 0,
    val nextAttemptAt: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "processed_ids")
data class ProcessedIdEntity(
    @PrimaryKey val messageId: String,
    val processedAt: Long = System.currentTimeMillis()
)

data class PeerUi(
    val peerId: String,
    val displayName: String,
    val connectionState: ConnectionState,
    val activeTransport: String?,
    val isTrusted: Boolean
)

data class MessageUi(
    val messageId: String,
    val body: String,
    val isOutgoing: Boolean,
    val status: MessageStatus,
    val timestamp: Long,
    val replyToId: String? = null
)
