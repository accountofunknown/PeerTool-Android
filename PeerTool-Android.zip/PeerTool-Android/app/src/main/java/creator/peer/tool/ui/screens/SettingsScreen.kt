package creator.peer.tool.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import creator.peer.tool.ui.viewmodel.MessagingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MessagingViewModel,
    onBack: () -> Unit,
    onAbout: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            ListItem(
                headlineContent = { Text("Privacy") },
                supportingContent = {
                    Text("Read receipts, discoverability, retention (planned)")
                },
                modifier = Modifier.fillMaxWidth()
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Notifications") },
                supportingContent = { Text("Message alerts (system notifications planned)") },
                modifier = Modifier.fillMaxWidth()
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("Storage & retention") },
                supportingContent = { Text("Local encrypted storage; backup excluded") },
                modifier = Modifier.fillMaxWidth()
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("About PeerTool") },
                trailingContent = {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onAbout)
            )
        }
    }
}
