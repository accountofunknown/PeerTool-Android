package creator.peer.tool.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import creator.peer.tool.ui.viewmodel.MessagingViewModel
import creator.peer.tool.util.QrUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdentityScreen(
    viewModel: MessagingViewModel,
    onBack: () -> Unit
) {
    val peerId by viewModel.myPeerId.collectAsState()
    val name by viewModel.displayName.collectAsState()
    val pubKey = viewModel.getPublicKey()
    val qrBitmap: Bitmap = remember(peerId, name) {
        QrUtils.toBitmap(viewModel.qrPayload(), 512)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Identity") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Share this QR with contacts", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            Image(
                bitmap = qrBitmap.asImageBitmap(),
                contentDescription = "Identity QR",
                modifier = Modifier.size(240.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text("Peer ID", style = MaterialTheme.typography.labelMedium)
            Text(peerId, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { viewModel.setDisplayName(it) },
                label = { Text("Display name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(Modifier.height(16.dp))
            Text("Public key (base64)", style = MaterialTheme.typography.labelMedium)
            Text(
                pubKey ?: "—",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "Nearby transport advertises this Peer ID. WebRTC requires a signaling URL (see Settings / About).",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
