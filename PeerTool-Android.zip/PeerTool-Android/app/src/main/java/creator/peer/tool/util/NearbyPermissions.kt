package creator.peer.tool.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

object NearbyPermissions {

    /**
     * Permissions required for Nearby Connections on the current API level.
     * Location is still requested on API 31–32 because some OEM stacks
     * need it for BLE scanning even when neverForLocation is set.
     */
    fun required(): Array<String> {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list += Manifest.permission.BLUETOOTH_SCAN
            list += Manifest.permission.BLUETOOTH_ADVERTISE
            list += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            list += Manifest.permission.BLUETOOTH
            list += Manifest.permission.BLUETOOTH_ADMIN
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list += Manifest.permission.NEARBY_WIFI_DEVICES
        }
        // Location: required pre-S; recommended S–T for broader device support
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            list += Manifest.permission.ACCESS_FINE_LOCATION
            list += Manifest.permission.ACCESS_COARSE_LOCATION
        }
        return list.distinct().toTypedArray()
    }

    fun missing(context: Context): List<String> {
        return required().filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
    }

    fun allGranted(context: Context): Boolean = missing(context).isEmpty()
}
