package creator.peer.tool.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("PeerTool", style = MaterialTheme.typography.headlineSmall)
            Text("Version 1.0.0-debug", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))
            Text(
                "Hybrid P2P messaging foundation for Android.\n\n" +
                    "This build includes:\n" +
                    "• Local cryptographic identity (Android Keystore)\n" +
                    "• Room persistence for peers, conversations, messages, outbox\n" +
                    "• Message status machine (queued → sending → delivered)\n" +
                    "• Jetpack Compose + Material 3 UI\n" +
                    "• Connection state model\n\n" +
                    "Not yet production-complete:\n" +
                    "• Real WebRTC / Nearby transport\n" +
                    "• Full end-to-end session encryption\n" +
                    "• Signaling / STUN / TURN\n" +
                    "• Background WorkManager recovery on force-stop\n\n" +
                    "Package: creator.peer.tool\n" +
                    "See COMPATIBILITY.md and README.md in the project for details.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
