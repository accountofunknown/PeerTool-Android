package creator.peer.tool.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("PeerTool", style = MaterialTheme.typography.headlineSmall)
            Text("Version 0.02", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(16.dp))
            Text(
                "Included in this build:\n" +
                    "• Nearby Connections transport (real offline P2P when permissions granted)\n" +
                    "• WebRTC transport scaffold (needs signaling URL for internet P2P)\n" +
                    "• Tink AES-GCM local encryption + ECDH helpers for peer keys\n" +
                    "• QR identity share (encode/decode)\n" +
                    "• Attachments stored encrypted on device\n" +
                    "• WorkManager outbox recovery (15 min)\n" +
                    "• Room persistence + message status machine\n\n" +
                    "Limitations:\n" +
                    "• WebRTC data channel not fully wired without a signaling server\n" +
                    "• Camera QR scan UI not included (paste QR JSON in Add Peer)\n" +
                    "• Full Signal/MLS ratchet not implemented\n" +
                    "• Force-stop requires user reopen before WorkManager resumes\n\n" +
                    "Package: creator.peer.tool",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
