package creator.peer.tool.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import creator.peer.tool.PeerToolApp
import creator.peer.tool.data.model.ConnectionState
import creator.peer.tool.ui.viewmodel.MessagingViewModel
import creator.peer.tool.util.NearbyPermissions
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NearbyScreen(
    viewModel: MessagingViewModel,
    onBack: () -> Unit,
    onOpenChat: (String) -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as PeerToolApp
    val peers by viewModel.peers.collectAsState()
    val scope = rememberCoroutineScope()
    var nearbyRunning by remember { mutableStateOf(false) }
    var statusMsg by remember { mutableStateOf("Nearby is stopped.") }
    var missingPerms by remember {
        mutableStateOf(NearbyPermissions.missing(context))
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        missingPerms = NearbyPermissions.missing(context)
        val ok = missingPerms.isEmpty()
        statusMsg = if (ok) {
            "Permissions granted. Tap Start Nearby."
        } else {
            "Still missing: ${missingPerms.joinToString { it.substringAfterLast('.') }}"
        }
        if (ok) {
            Toast.makeText(context, "Permissions OK", Toast.LENGTH_SHORT).show()
        }
    }

    fun refreshPerms() {
        missingPerms = NearbyPermissions.missing(context)
    }

    LaunchedEffect(Unit) { refreshPerms() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nearby (offline)") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        refreshPerms()
                        scope.launch {
                            if (NearbyPermissions.allGranted(context)) {
                                app.messagingRepository.startNearby()
                                nearbyRunning = true
                                statusMsg = "Restarted advertising + discovery."
                            }
                        }
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                "How to use Nearby",
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                "1. Grant permissions below on both phones.\n" +
                    "2. Turn on Bluetooth (and Wi‑Fi recommended).\n" +
                    "3. Tap Start Nearby on both devices.\n" +
                    "4. Keep phones within a few meters.\n" +
                    "5. When a peer shows CONNECTED, open chat and send.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            Text(statusMsg, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))

            if (missingPerms.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            "Permissions needed",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            missingPerms.joinToString("\n") { "• ${it.substringAfterLast('.')}" },
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = {
                            permLauncher.launch(NearbyPermissions.required())
                        }) {
                            Text("Grant permissions")
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (!NearbyPermissions.allGranted(context)) {
                            permLauncher.launch(NearbyPermissions.required())
                            statusMsg = "Grant permissions first."
                            return@Button
                        }
                        scope.launch {
                            try {
                                app.messagingRepository.startNearby()
                                nearbyRunning = true
                                statusMsg = "Nearby started — advertising as ${viewModel.myPeerId.value}"
                                Toast.makeText(context, "Nearby started", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                statusMsg = "Start failed: ${e.message}"
                            }
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.BluetoothSearching, contentDescription = null)
                    Text("  Start Nearby")
                }
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            app.messagingRepository.stopNearby()
                            nearbyRunning = false
                            statusMsg = "Nearby stopped."
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Stop")
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                if (nearbyRunning) "Peers (live)" else "Peers",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))

            if (peers.isEmpty()) {
                Text(
                    "No peers yet. Start Nearby on both devices, or add a Peer ID under Contacts.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(peers, key = { it.peerId }) { peer ->
                        val color = when (peer.connectionState) {
                            ConnectionState.CONNECTED -> Color(0xFF4CAF50)
                            ConnectionState.CONNECTING, ConnectionState.RECONNECTING -> Color(0xFFFFC107)
                            ConnectionState.DISCOVERED -> Color(0xFF2196F3)
                            ConnectionState.FAILED -> Color(0xFFF44336)
                            else -> Color.Gray
                        }
                        Card(
                            onClick = { onOpenChat(peer.peerId) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Circle, null, tint = color)
                                Column(Modifier.padding(start = 12.dp).weight(1f)) {
                                    Text(peer.displayName, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${peer.peerId} · ${peer.connectionState.name}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    if (peer.activeTransport != null) {
                                        Text(
                                            "via ${peer.activeTransport}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
