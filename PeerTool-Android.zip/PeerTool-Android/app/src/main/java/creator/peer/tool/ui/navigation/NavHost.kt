package creator.peer.tool.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import creator.peer.tool.PeerToolApp
import creator.peer.tool.ui.screens.AboutScreen
import creator.peer.tool.ui.screens.ChatScreen
import creator.peer.tool.ui.screens.ContactsScreen
import creator.peer.tool.ui.screens.ConversationListScreen
import creator.peer.tool.ui.screens.IdentityScreen
import creator.peer.tool.ui.screens.OnboardingScreen
import creator.peer.tool.ui.screens.SettingsScreen
import creator.peer.tool.ui.screens.NearbyScreen
import creator.peer.tool.ui.viewmodel.MessagingViewModel
import creator.peer.tool.ui.viewmodel.MessagingViewModelFactory

object Routes {
    const val ONBOARDING = "onboarding"
    const val IDENTITY = "identity"
    const val CONVERSATIONS = "conversations"
    const val CONTACTS = "contacts"
    const val CHAT = "chat/{peerId}"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
    const val NEARBY = "nearby"

    fun chat(peerId: String) = "chat/$peerId"
}

@Composable
fun PeerToolNavHost() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val app = context.applicationContext as PeerToolApp
    val factory = remember {
        MessagingViewModelFactory(app.messagingRepository, app.identityManager)
    }
    val vm: MessagingViewModel = viewModel(factory = factory)

    val start = if (app.identityManager.hasIdentity()) Routes.CONVERSATIONS else Routes.ONBOARDING

    NavHost(navController = navController, startDestination = start) {
        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                onContinue = {
                    vm.ensureIdentity()
                    navController.navigate(Routes.CONVERSATIONS) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.IDENTITY) {
            IdentityScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.CONVERSATIONS) {
            ConversationListScreen(
                viewModel = vm,
                onOpenChat = { peerId -> navController.navigate(Routes.chat(peerId)) },
                onOpenContacts = { navController.navigate(Routes.CONTACTS) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                onOpenIdentity = { navController.navigate(Routes.IDENTITY) },
                onOpenNearby = { navController.navigate(Routes.NEARBY) }
            )
        }
        composable(Routes.CONTACTS) {
            ContactsScreen(
                viewModel = vm,
                onOpenChat = { peerId ->
                    navController.navigate(Routes.chat(peerId)) {
                        popUpTo(Routes.CONTACTS)
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            route = Routes.CHAT,
            arguments = listOf(navArgument("peerId") { type = NavType.StringType })
        ) { entry ->
            val peerId = entry.arguments?.getString("peerId") ?: return@composable
            ChatScreen(
                peerId = peerId,
                viewModel = vm,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onAbout = { navController.navigate(Routes.ABOUT) }
            )
        }
        composable(Routes.NEARBY) {
            NearbyScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onOpenChat = { peerId -> navController.navigate(Routes.chat(peerId)) }
            )
        }
        composable(Routes.ABOUT) {
            AboutScreen(onBack = { navController.popBackStack() })
        }
    }
}
