package creator.peer.tool.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import creator.peer.tool.data.model.ConversationEntity
import creator.peer.tool.data.model.MessageEntity
import creator.peer.tool.data.model.OutboxEntity
import creator.peer.tool.data.model.PeerEntity
import creator.peer.tool.data.model.ProcessedIdEntity

@Database(
    entities = [
        PeerEntity::class,
        ConversationEntity::class,
        MessageEntity::class,
        OutboxEntity::class,
        ProcessedIdEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PeerToolDatabase : RoomDatabase() {
    abstract fun peerDao(): PeerDao
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun outboxDao(): OutboxDao
    abstract fun processedDao(): ProcessedDao

    companion object {
        @Volatile
        private var INSTANCE: PeerToolDatabase? = null

        fun getInstance(context: Context): PeerToolDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PeerToolDatabase::class.java,
                    "peertool.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
