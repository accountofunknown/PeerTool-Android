package creator.peer.tool.messaging

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import creator.peer.tool.PeerToolApp
import java.util.concurrent.TimeUnit

/**
 * Periodically drains the persistent outbox after process death / Doze.
 * Force-stop still requires user to reopen the app before WorkManager resumes.
 */
class OutboxWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            val app = applicationContext as? PeerToolApp
                ?: return Result.retry()
            app.messagingRepository.processOutbox()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE = "peertool_outbox"

        fun schedule(context: Context) {
            val req = PeriodicWorkRequestBuilder<OutboxWorker>(15, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE,
                ExistingPeriodicWorkPolicy.KEEP,
                req
            )
        }
    }
}
