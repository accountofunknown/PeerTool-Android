package creator.peer.tool

import android.app.Application
import creator.peer.tool.crypto.IdentityManager
import creator.peer.tool.crypto.MessageCrypto
import creator.peer.tool.data.db.PeerToolDatabase
import creator.peer.tool.data.repo.MessagingRepository
import creator.peer.tool.messaging.OutboxWorker
import creator.peer.tool.transport.NearbyTransport
import creator.peer.tool.transport.TransportRouter
import creator.peer.tool.transport.WebRtcTransport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class PeerToolApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    lateinit var database: PeerToolDatabase
        private set
    lateinit var identityManager: IdentityManager
        private set
    lateinit var messageCrypto: MessageCrypto
        private set
    lateinit var messagingRepository: MessagingRepository
        private set
    lateinit var transportRouter: TransportRouter
        private set
    lateinit var nearbyTransport: NearbyTransport
        private set

    override fun onCreate() {
        super.onCreate()
        database = PeerToolDatabase.getInstance(this)
        identityManager = IdentityManager(this)
        if (!identityManager.hasIdentity()) {
            identityManager.createIdentity()
        }
        messageCrypto = MessageCrypto(this)
        nearbyTransport = NearbyTransport(this, identityManager)
        val webrtc = WebRtcTransport(this, identityManager)
        transportRouter = TransportRouter(nearbyTransport, webrtc, identityManager)
        messagingRepository = MessagingRepository(
            this, database, identityManager, messageCrypto, transportRouter
        )
        OutboxWorker.schedule(this)
        // Do NOT start Nearby here — needs runtime permissions from UI (Nearby screen).
        appScope.launch {
            webrtc.start()
        }
    }
}
