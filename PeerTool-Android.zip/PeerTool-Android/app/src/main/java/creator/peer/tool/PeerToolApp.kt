package creator.peer.tool

import android.app.Application
import creator.peer.tool.data.db.PeerToolDatabase
import creator.peer.tool.data.repo.MessagingRepository
import creator.peer.tool.crypto.IdentityManager

class PeerToolApp : Application() {
    lateinit var database: PeerToolDatabase
        private set
    lateinit var identityManager: IdentityManager
        private set
    lateinit var messagingRepository: MessagingRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = PeerToolDatabase.getInstance(this)
        identityManager = IdentityManager(this)
        messagingRepository = MessagingRepository(database, identityManager)
    }
}
