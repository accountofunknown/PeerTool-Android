package creator.peer.tool.transport

import android.util.Log
import creator.peer.tool.crypto.IdentityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

/**
 * Hybrid router: prefers Nearby when connected, falls back to WebRTC, then fails.
 * Does not downgrade encryption; only selects path.
 */
class TransportRouter(
    private val nearby: NearbyTransport,
    private val webrtc: WebRtcTransport,
    private val identity: IdentityManager
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _incoming = MutableSharedFlow<IncomingEnvelope>(extraBufferCapacity = 128)
    val incoming: SharedFlow<IncomingEnvelope> = _incoming.asSharedFlow()

    init {
        scope.launch {
            nearby.incoming.collect { _incoming.emit(it) }
        }
        scope.launch {
            webrtc.incoming.collect { _incoming.emit(it) }
        }
    }

    suspend fun start() {
        nearby.start()
        webrtc.start()
    }

    suspend fun stop() {
        nearby.stop()
        webrtc.stop()
    }

    suspend fun send(peerId: String, messageId: String, payload: ByteArray): Pair<Boolean, TransportType?> {
        if (peerId == identity.peerId) {
            // Local loopback for self-chat demo
            _incoming.emit(IncomingEnvelope(peerId, messageId + "-echo", payload, TransportType.LOCAL_DEMO))
            return true to TransportType.LOCAL_DEMO
        }
        if (nearby.isConnected(peerId)) {
            val ok = nearby.send(peerId, messageId, payload)
            if (ok) return true to TransportType.NEARBY
        }
        if (webrtc.isConnected(peerId)) {
            val ok = webrtc.send(peerId, messageId, payload)
            if (ok) return true to TransportType.WEBRTC
        }
        // Try to establish Nearby (discovery may already be running)
        nearby.connect(peerId)
        if (nearby.isConnected(peerId)) {
            val ok = nearby.send(peerId, messageId, payload)
            if (ok) return true to TransportType.NEARBY
        }
        Log.w(TAG, "No route to $peerId")
        return false to null
    }

    fun activeTransportFor(peerId: String): TransportType? = when {
        nearby.isConnected(peerId) -> TransportType.NEARBY
        webrtc.isConnected(peerId) -> TransportType.WEBRTC
        else -> null
    }

    fun nearbyStates() = nearby.connectionStates
    fun webrtcStates() = webrtc.connectionStates

    companion object {
        private const val TAG = "TransportRouter"
    }
}
