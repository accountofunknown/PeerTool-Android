package creator.peer.tool.data.repo

import creator.peer.tool.crypto.IdentityManager
import creator.peer.tool.data.db.PeerToolDatabase
import creator.peer.tool.data.model.ConnectionState
import creator.peer.tool.data.model.ConversationEntity
import creator.peer.tool.data.model.MessageEntity
import creator.peer.tool.data.model.MessageStatus
import creator.peer.tool.data.model.MessageUi
import creator.peer.tool.data.model.OutboxEntity
import creator.peer.tool.data.model.PeerEntity
import creator.peer.tool.data.model.PeerUi
import creator.peer.tool.data.model.ProcessedIdEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Core messaging repository.
 *
 * Delivery path (intended production flow):
 * 1. Validate + generate stable messageId
 * 2. Encrypt envelope (extension point)
 * 3. Persist message + outbox atomically
 * 4. Select route (internet / nearby / relay)
 * 5. Transmit, await durable ack
 * 6. Update status transactionally
 *
 * Current implementation provides local persistence, outbox,
 * status machine and a local loopback "echo" for single-device demo.
 * Real transports (WebRTC data channel, Nearby Connections) must
 * replace the sendToTransport stub.
 */
class MessagingRepository(
    private val db: PeerToolDatabase,
    private val identity: IdentityManager
) {
    private val peerDao = db.peerDao()
    private val conversationDao = db.conversationDao()
    private val messageDao = db.messageDao()
    private val outboxDao = db.outboxDao()
    private val processedDao = db.processedDao()

    fun observePeers(): Flow<List<PeerUi>> = peerDao.observePeers().map { list ->
        list.map {
            PeerUi(
                peerId = it.peerId,
                displayName = it.displayName,
                connectionState = runCatching { ConnectionState.valueOf(it.connectionState) }
                    .getOrDefault(ConnectionState.DISCONNECTED),
                activeTransport = it.activeTransport,
                isTrusted = it.isTrusted
            )
        }
    }

    fun observeConversations() = conversationDao.observeConversations()

    fun observeMessages(conversationId: String): Flow<List<MessageUi>> =
        messageDao.observeMessages(conversationId).map { list ->
            list.map {
                MessageUi(
                    messageId = it.messageId,
                    body = it.body,
                    isOutgoing = it.isOutgoing,
                    status = runCatching { MessageStatus.valueOf(it.status) }
                        .getOrDefault(MessageStatus.QUEUED),
                    timestamp = it.createdAt,
                    replyToId = it.replyToId
                )
            }
        }

    suspend fun addPeer(peerId: String, displayName: String = peerId.take(8)) =
        withContext(Dispatchers.IO) {
            val existing = peerDao.getPeer(peerId)
            if (existing == null) {
                peerDao.upsert(
                    PeerEntity(
                        peerId = peerId,
                        displayName = displayName.ifBlank { peerId.take(8) },
                        connectionState = ConnectionState.DISCONNECTED.name
                    )
                )
            }
            ensureConversation(peerId)
        }

    suspend fun ensureConversation(peerId: String): String = withContext(Dispatchers.IO) {
        val existing = conversationDao.getByPeer(peerId)
        if (existing != null) return@withContext existing.conversationId
        val id = UUID.randomUUID().toString()
        conversationDao.upsert(
            ConversationEntity(
                conversationId = id,
                peerId = peerId
            )
        )
        id
    }

    suspend fun sendText(peerId: String, body: String): String = withContext(Dispatchers.IO) {
        val conversationId = ensureConversation(peerId)
        val messageId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()

        // 1-4. Persist message + outbox
        val message = MessageEntity(
            messageId = messageId,
            conversationId = conversationId,
            peerId = peerId,
            isOutgoing = true,
            body = body.trim(),
            status = MessageStatus.QUEUED.name,
            createdAt = now
        )
        messageDao.insert(message)
        conversationDao.updateLastMessage(conversationId, body.take(80), now, 0)

        val job = OutboxEntity(
            messageId = messageId,
            peerId = peerId,
            payload = body.trim()
        )
        outboxDao.insert(job)

        // 5. Attempt immediate delivery (stub transport)
        attemptDelivery(job)

        messageId
    }

    private suspend fun attemptDelivery(job: OutboxEntity) {
        // Placeholder: real implementation would pick transport and send encrypted envelope.
        // For demo we mark as SENT after a short simulated path and also loopback for self-chat.
        messageDao.updateStatus(job.messageId, MessageStatus.SENDING.name)
        try {
            // Simulated successful transmission
            messageDao.updateStatus(
                job.messageId,
                MessageStatus.SENT.name,
                System.currentTimeMillis()
            )
            // Durable ack simulation
            messageDao.updateStatus(
                job.messageId,
                MessageStatus.DELIVERED.name,
                System.currentTimeMillis()
            )
            outboxDao.delete(job.jobId)

            // If messaging self (demo), also insert incoming
            if (job.peerId == identity.peerId) {
                receiveMessage(job.peerId, job.messageId + "-echo", job.payload)
            }
        } catch (e: Exception) {
            val next = System.currentTimeMillis() + (1L shl job.attempts.coerceAtMost(6)) * 1000L
            outboxDao.markAttempt(job.jobId, next)
            messageDao.updateStatus(job.messageId, MessageStatus.FAILED.name)
        }
    }

    suspend fun receiveMessage(
        fromPeerId: String,
        messageId: String,
        body: String
    ) = withContext(Dispatchers.IO) {
        // Dedup
        if (processedDao.exists(messageId) > 0) return@withContext
        processedDao.insert(ProcessedIdEntity(messageId))

        val conversationId = ensureConversation(fromPeerId)
        val now = System.currentTimeMillis()
        messageDao.insert(
            MessageEntity(
                messageId = messageId,
                conversationId = conversationId,
                peerId = fromPeerId,
                isOutgoing = false,
                body = body,
                status = MessageStatus.DELIVERED.name,
                createdAt = now,
                deliveredAt = now
            )
        )
        conversationDao.updateLastMessage(conversationId, body.take(80), now, 1)
    }

    suspend fun setConnectionState(
        peerId: String,
        state: ConnectionState,
        transport: String? = null
    ) = withContext(Dispatchers.IO) {
        peerDao.updateConnection(peerId, state.name, transport)
    }

    suspend fun processOutbox() = withContext(Dispatchers.IO) {
        val pending = outboxDao.getPending()
        for (job in pending) {
            if (job.nextAttemptAt <= System.currentTimeMillis()) {
                attemptDelivery(job)
            }
        }
    }

    suspend fun getOrCreateLocalPeer() {
        // Ensure own identity appears if needed for self-chat demos
        val id = identity.peerId
        addPeer(id, identity.displayName)
    }
}
