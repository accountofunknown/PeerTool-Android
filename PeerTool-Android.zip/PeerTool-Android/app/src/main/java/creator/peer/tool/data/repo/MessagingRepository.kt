package creator.peer.tool.data.repo

import android.content.Context
import android.net.Uri
import creator.peer.tool.crypto.IdentityManager
import creator.peer.tool.crypto.MessageCrypto
import creator.peer.tool.data.db.PeerToolDatabase
import creator.peer.tool.data.model.AttachmentEntity
import creator.peer.tool.data.model.AttachmentStatus
import creator.peer.tool.data.model.ConnectionState
import creator.peer.tool.data.model.ConversationEntity
import creator.peer.tool.data.model.MessageEntity
import creator.peer.tool.data.model.MessageStatus
import creator.peer.tool.data.model.MessageUi
import creator.peer.tool.data.model.OutboxEntity
import creator.peer.tool.data.model.PeerEntity
import creator.peer.tool.data.model.PeerUi
import creator.peer.tool.data.model.ProcessedIdEntity
import creator.peer.tool.transport.TransportRouter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class MessagingRepository(
    private val context: Context,
    private val db: PeerToolDatabase,
    private val identity: IdentityManager,
    private val crypto: MessageCrypto,
    private val router: TransportRouter
) {
    private val peerDao = db.peerDao()
    private val conversationDao = db.conversationDao()
    private val messageDao = db.messageDao()
    private val outboxDao = db.outboxDao()
    private val processedDao = db.processedDao()
    private val attachmentDao = db.attachmentDao()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    init {
        scope.launch {
            router.incoming.collect { env ->
                handleIncoming(env.fromPeerId, env.messageId, env.payload)
            }
        }
        scope.launch {
            router.nearbyStates().collect { map ->
                map.forEach { (peerId, state) ->
                    val cs = runCatching { ConnectionState.valueOf(state) }
                        .getOrDefault(ConnectionState.DISCONNECTED)
                    peerDao.updateConnection(
                        peerId,
                        cs.name,
                        router.activeTransportFor(peerId)?.name
                    )
                }
            }
        }
    }

    suspend fun startTransports() = withContext(Dispatchers.IO) {
        router.start()
    }

    fun observePeers(): Flow<List<PeerUi>> = peerDao.observePeers().map { list ->
        list.map {
            PeerUi(
                peerId = it.peerId,
                displayName = it.displayName,
                connectionState = runCatching { ConnectionState.valueOf(it.connectionState) }
                    .getOrDefault(ConnectionState.DISCONNECTED),
                activeTransport = it.activeTransport,
                isTrusted = it.isTrusted
            )
        }
    }

    fun observeConversations() = conversationDao.observeConversations()

    fun observeMessages(conversationId: String): Flow<List<MessageUi>> =
        messageDao.observeMessages(conversationId).map { list ->
            list.map {
                MessageUi(
                    messageId = it.messageId,
                    body = tryDecryptBody(it.body),
                    isOutgoing = it.isOutgoing,
                    status = runCatching { MessageStatus.valueOf(it.status) }
                        .getOrDefault(MessageStatus.QUEUED),
                    timestamp = it.createdAt,
                    replyToId = it.replyToId
                )
            }
        }

    private fun tryDecryptBody(stored: String): String {
        return try {
            crypto.decryptLocalString(stored)
        } catch (_: Exception) {
            stored
        }
    }

    suspend fun addPeer(peerId: String, displayName: String = peerId.take(8), publicKey: String? = null) =
        withContext(Dispatchers.IO) {
            peerDao.upsert(
                PeerEntity(
                    peerId = peerId,
                    displayName = displayName.ifBlank { peerId.take(8) },
                    publicKeyPem = publicKey,
                    connectionState = ConnectionState.DISCONNECTED.name
                )
            )
            ensureConversation(peerId)
        }

    suspend fun ensureConversation(peerId: String): String = withContext(Dispatchers.IO) {
        val existing = conversationDao.getByPeer(peerId)
        if (existing != null) return@withContext existing.conversationId
        val id = UUID.randomUUID().toString()
        conversationDao.upsert(ConversationEntity(conversationId = id, peerId = peerId))
        id
    }

    suspend fun sendText(peerId: String, body: String): String = withContext(Dispatchers.IO) {
        val conversationId = ensureConversation(peerId)
        val messageId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val encryptedBody = crypto.encryptLocalString(body.trim())

        messageDao.insert(
            MessageEntity(
                messageId = messageId,
                conversationId = conversationId,
                peerId = peerId,
                isOutgoing = true,
                body = encryptedBody,
                status = MessageStatus.QUEUED.name,
                createdAt = now
            )
        )
        conversationDao.updateLastMessage(conversationId, body.take(80), now, 0)

        val payload = body.trim().toByteArray(Charsets.UTF_8)
        outboxDao.insert(
            OutboxEntity(
                messageId = messageId,
                peerId = peerId,
                payload = android.util.Base64.encodeToString(payload, android.util.Base64.NO_WRAP)
            )
        )
        attemptDelivery(messageId, peerId, payload)
        messageId
    }

    private suspend fun attemptDelivery(messageId: String, peerId: String, payload: ByteArray) {
        messageDao.updateStatus(messageId, MessageStatus.SENDING.name)
        val (ok, transport) = router.send(peerId, messageId, payload)
        if (ok) {
            messageDao.updateStatus(messageId, MessageStatus.SENT.name, System.currentTimeMillis())
            messageDao.updateStatus(messageId, MessageStatus.DELIVERED.name, System.currentTimeMillis())
            outboxDao.getPending().filter { it.messageId == messageId }.forEach {
                outboxDao.delete(it.jobId)
            }
            if (transport != null) {
                peerDao.updateConnection(peerId, ConnectionState.CONNECTED.name, transport.name)
            }
        } else {
            messageDao.updateStatus(messageId, MessageStatus.FAILED.name)
        }
    }

    private suspend fun handleIncoming(fromPeerId: String, messageId: String, payload: ByteArray) {
        if (processedDao.exists(messageId) > 0) return
        processedDao.insert(ProcessedIdEntity(messageId))
        addPeer(fromPeerId)
        val conversationId = ensureConversation(fromPeerId)
        val body = String(payload, Charsets.UTF_8)
        val encrypted = crypto.encryptLocalString(body)
        val now = System.currentTimeMillis()
        messageDao.insert(
            MessageEntity(
                messageId = messageId,
                conversationId = conversationId,
                peerId = fromPeerId,
                isOutgoing = false,
                body = encrypted,
                status = MessageStatus.DELIVERED.name,
                createdAt = now,
                deliveredAt = now
            )
        )
        conversationDao.updateLastMessage(conversationId, body.take(80), now, 1)
    }

    suspend fun processOutbox() = withContext(Dispatchers.IO) {
        for (job in outboxDao.getPending()) {
            if (job.nextAttemptAt > System.currentTimeMillis()) continue
            val payload = android.util.Base64.decode(job.payload, android.util.Base64.NO_WRAP)
            attemptDelivery(job.messageId, job.peerId, payload)
            val next = System.currentTimeMillis() + (1L shl job.attempts.coerceAtMost(6)) * 1000L
            outboxDao.markAttempt(job.jobId, next)
        }
    }

    suspend fun addAttachment(
        peerId: String,
        uri: Uri,
        fileName: String,
        mimeType: String
    ): String = withContext(Dispatchers.IO) {
        val messageId = sendText(peerId, "[attachment] $fileName")
        val destDir = File(context.filesDir, "attachments").apply { mkdirs() }
        val dest = File(destDir, "${UUID.randomUUID()}_$fileName")
        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        }
        val plain = dest.readBytes()
        val encrypted = crypto.encryptLocal(plain, messageId.toByteArray())
        dest.writeBytes(encrypted)
        attachmentDao.upsert(
            AttachmentEntity(
                messageId = messageId,
                peerId = peerId,
                fileName = fileName,
                mimeType = mimeType,
                sizeBytes = plain.size.toLong(),
                localPath = dest.absolutePath,
                status = AttachmentStatus.COMPLETE.name,
                progress = 1f,
                isOutgoing = true
            )
        )
        messageId
    }

    suspend fun getOrCreateLocalPeer() {
        addPeer(identity.peerId, identity.displayName)
    }
}
