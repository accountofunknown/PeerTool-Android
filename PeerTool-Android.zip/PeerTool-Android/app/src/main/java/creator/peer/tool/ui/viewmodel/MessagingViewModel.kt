package creator.peer.tool.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import creator.peer.tool.crypto.IdentityManager
import creator.peer.tool.data.model.ConnectionState
import creator.peer.tool.data.model.MessageUi
import creator.peer.tool.data.model.PeerUi
import creator.peer.tool.data.repo.MessagingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MessagingViewModel(
    private val repo: MessagingRepository,
    private val identity: IdentityManager
) : ViewModel() {

    val peers: StateFlow<List<PeerUi>> = repo.observePeers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val conversations = repo.observeConversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _messages = MutableStateFlow<List<MessageUi>>(emptyList())
    val messages: StateFlow<List<MessageUi>> = _messages.asStateFlow()

    private val _myPeerId = MutableStateFlow(identity.peerId)
    val myPeerId: StateFlow<String> = _myPeerId.asStateFlow()

    private val _displayName = MutableStateFlow(identity.displayName)
    val displayName: StateFlow<String> = _displayName.asStateFlow()

    private var currentConversationId: String? = null
    private var currentPeerId: String? = null

    fun ensureIdentity() {
        viewModelScope.launch {
            identity.createIdentity()
            _myPeerId.value = identity.peerId
            _displayName.value = identity.displayName
            repo.getOrCreateLocalPeer()
        }
    }

    fun setDisplayName(name: String) {
        identity.setDisplayName(name)
        _displayName.value = identity.displayName
    }

    fun addPeer(peerId: String, name: String = "") {
        viewModelScope.launch {
            repo.addPeer(peerId.trim(), name.ifBlank { peerId.take(8) })
            // Demo: mark as connected on local add
            repo.setConnectionState(peerId.trim(), ConnectionState.CONNECTED, "local-demo")
        }
    }

    fun openChat(peerId: String) {
        currentPeerId = peerId
        viewModelScope.launch {
            val convId = repo.ensureConversation(peerId)
            currentConversationId = convId
            repo.observeMessages(convId).collect { list ->
                _messages.value = list
            }
        }
    }

    fun sendMessage(text: String) {
        val peerId = currentPeerId ?: return
        if (text.isBlank()) return
        viewModelScope.launch {
            repo.sendText(peerId, text)
        }
    }

    fun getPublicKey(): String? = identity.getPublicKeyBase64()
}

class MessagingViewModelFactory(
    private val repo: MessagingRepository,
    private val identity: IdentityManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MessagingViewModel::class.java)) {
            return MessagingViewModel(repo, identity) as T
        }
        throw IllegalArgumentException("Unknown ViewModel")
    }
}
