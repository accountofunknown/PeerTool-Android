package creator.peer.tool.crypto

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.Signature
import java.util.UUID

/**
 * Manages local peer identity.
 * Uses Android Keystore when available for the signing key.
 * Peer ID is a stable short hash derived from the public key.
 *
 * NOTE: This provides identity + basic authenticity.
 * Full end-to-end encryption (Signal / MLS style session keys,
 * double ratchet, etc.) is intentionally left as a clear extension
 * point. Do not claim perfect E2E privacy until a reviewed protocol
 * is integrated and audited.
 */
class IdentityManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("peertool_identity", Context.MODE_PRIVATE)

    private val keyAlias = "peertool_identity_key"

    val peerId: String
        get() = prefs.getString(KEY_PEER_ID, null) ?: createIdentity()

    val displayName: String
        get() = prefs.getString(KEY_DISPLAY_NAME, null) ?: "Peer-${peerId.take(6)}"

    fun setDisplayName(name: String) {
        prefs.edit().putString(KEY_DISPLAY_NAME, name.trim()).apply()
    }

    fun hasIdentity(): Boolean = prefs.contains(KEY_PEER_ID)

    fun createIdentity(): String {
        val keyPair = generateOrLoadKeyPair()
        val pubBytes = keyPair.public.encoded
        val id = shortIdFromPublicKey(pubBytes)
        prefs.edit()
            .putString(KEY_PEER_ID, id)
            .putString(KEY_PUBLIC_KEY_B64, Base64.encodeToString(pubBytes, Base64.NO_WRAP))
            .apply()
        return id
    }

    fun getPublicKeyBase64(): String? = prefs.getString(KEY_PUBLIC_KEY_B64, null)

    fun sign(data: ByteArray): ByteArray? {
        return try {
            val privateKey = loadPrivateKey() ?: return null
            val sig = Signature.getInstance("SHA256withECDSA")
            sig.initSign(privateKey)
            sig.update(data)
            sig.sign()
        } catch (e: Exception) {
            null
        }
    }

    fun verify(publicKeyBytes: ByteArray, data: ByteArray, signature: ByteArray): Boolean {
        return try {
            val keyFactory = java.security.KeyFactory.getInstance("EC")
            val pubKey = keyFactory.generatePublic(
                java.security.spec.X509EncodedKeySpec(publicKeyBytes)
            )
            val sig = Signature.getInstance("SHA256withECDSA")
            sig.initVerify(pubKey)
            sig.update(data)
            sig.verify(signature)
        } catch (e: Exception) {
            false
        }
    }

    private fun generateOrLoadKeyPair(): KeyPair {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (ks.containsAlias(keyAlias)) {
            val entry = ks.getEntry(keyAlias, null) as KeyStore.PrivateKeyEntry
            return KeyPair(entry.certificate.publicKey, entry.privateKey)
        }
        val kpg = KeyPairGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_EC,
            "AndroidKeyStore"
        )
        val spec = KeyGenParameterSpec.Builder(
            keyAlias,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
        )
            .setDigests(KeyProperties.DIGEST_SHA256)
            .setAlgorithmParameterSpec(java.security.spec.ECGenParameterSpec("secp256r1"))
            .build()
        kpg.initialize(spec)
        return kpg.generateKeyPair()
    }

    private fun loadPrivateKey(): PrivateKey? {
        return try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val entry = ks.getEntry(keyAlias, null) as? KeyStore.PrivateKeyEntry
            entry?.privateKey
        } catch (e: Exception) {
            null
        }
    }

    private fun shortIdFromPublicKey(pub: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(pub)
        return Base64.encodeToString(digest, Base64.URL_SAFE or Base64.NO_WRAP)
            .take(16)
            .replace("=", "")
            .replace("-", "")
            .replace("_", "")
    }

    companion object {
        private const val KEY_PEER_ID = "peer_id"
        private const val KEY_DISPLAY_NAME = "display_name"
        private const val KEY_PUBLIC_KEY_B64 = "public_key_b64"
    }
}
