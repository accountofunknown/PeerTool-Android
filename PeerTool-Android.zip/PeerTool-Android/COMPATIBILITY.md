# PeerTool Compatibility Report

Generated for the deliverable dated 2026-10-26.

## Selected toolchain

| Component              | Version          | Rationale |
|------------------------|------------------|-----------|
| Android Gradle Plugin  | 8.7.3            | Stable, widely used with Gradle 8.9; good GHA support |
| Gradle                 | 8.9              | Required minimum for AGP 8.7.x family |
| Kotlin                 | 2.0.21           | Stable, matches Compose compiler plugin |
| KSP                    | 2.0.21-1.0.28    | Matches Kotlin version |
| compileSdk / targetSdk | 35               | Android 15; meets current Play requirements at time of writing |
| minSdk                 | 26               | Covers ~95%+ devices; Keystore + modern APIs available |
| Compose BOM            | 2024.12.01       | Stable Material 3 + UI |
| Room                   | 2.6.1            | Mature, coroutine support |
| WorkManager            | 2.10.0           | Background work |
| Java / JDK             | 17               | Required by recent AGP |

Sources consulted: developer.android.com AGP release notes, Compose BOM docs, Gradle compatibility table.

## Known limitations

1. **No Android SDK in the generation environment** — the APK was not compiled or instrumented here. First successful build is expected from GitHub Actions.
2. **Transport layer** — WebRTC / Nearby are architectural stubs. Real connectivity requires additional libraries (e.g. Google WebRTC, Nearby Connections) and a signaling service.
3. **E2E encryption** — Identity signing is present; message payload encryption and session key agreement are not yet implemented.
4. **Debug APK only** — Release signing is intentionally out of scope for this pipeline.
5. **Background limits** — Force-stopped apps on modern Android will not auto-recover until the user reopens the app.

## Package identity

- applicationId / namespace: `creator.peer.tool`
- Debug suffix: `.debug` → `creator.peer.tool.debug`
