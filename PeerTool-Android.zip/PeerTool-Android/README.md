# PeerTool

**Package ID:** `creator.peer.tool`  
**Application name:** PeerTool  
**Platform:** Android (minSdk 26, targetSdk 35)

Privacy-oriented hybrid P2P messaging foundation for Android, built with Kotlin, Jetpack Compose, Material 3, and Room.

## What this build includes

- Local cryptographic identity (EC key in Android Keystore, stable Peer ID)
- Room database: peers, conversations, messages, outbox, processed-message IDs
- Message lifecycle: queued → sending → sent → delivered (with failure/retry skeleton)
- Connection-state model (DISCOVERED … FAILED)
- Full Compose UI: onboarding, identity, contacts, conversation list, chat, settings, about
- Architecture ready for real transports (WebRTC data channels, Nearby Connections, relay)

## What is intentionally not complete

- Real multi-device WebRTC or PeerJS transport (requires signaling + STUN/TURN)
- Nearby / Bluetooth offline mesh (requires runtime permissions + device testing)
- Full Signal/MLS-style end-to-end session encryption
- Production background recovery under force-stop / Doze (WorkManager hooks present as extension)
- Attachments, reactions, read receipts UI wiring

These are documented extension points, not claimed as finished features.

## Build with GitHub Actions (phone-friendly)

1. Create a new public or private GitHub repository.
2. Upload **PeerTool-Android.zip** and **peer-tool-android.yml** to the repository root.
3. Move the workflow file into `.github/workflows/` (GitHub web UI: create folder `.github/workflows` and upload the YAML there, or rename after upload).
4. Open the **Actions** tab → select the workflow → **Run workflow**.
5. When finished, download the **PeerTool-debug-APK** artifact and install the APK.

Alternatively, the workflow can be configured to run on every push of the ZIP.

## Local build (desktop)

```bash
./gradlew assembleDebug
```

APK path: `app/build/outputs/apk/debug/app-debug.apk`  
(Debug variant uses applicationId `creator.peer.tool.debug`.)

## Security notes

- Identity private key is generated inside Android Keystore.
- Auto-backup of databases and shared preferences is disabled.
- No API keys or secrets are embedded.
- End-to-end encryption of message bodies is an extension point; current demo uses cleartext local storage for the local-demo path only.

## License

Source delivered for the PeerTool project. Use and modify as needed.
