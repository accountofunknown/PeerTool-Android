# PeerTool 1.1

Package: `creator.peer.tool`

## What is implemented

1. **Nearby offline transport** – Google Play Services Nearby Connections (P2P_STAR). Advertise + discover by Peer ID. Requires Bluetooth / Nearby Wi-Fi / location permissions at runtime.
2. **WebRTC transport scaffold** – MessagingTransport interface + ICE STUN list. Full data-channel needs a signaling server URL (documented).
3. **Stronger encryption** – Google Tink AES-256-GCM for local storage; ECDH helpers for peer shared keys.
4. **QR identity** – Encode identity JSON to QR on Identity screen; paste QR JSON or Peer ID in Add Peer.
5. **Attachments** – Pick file from chat, encrypt at rest with Tink, store under app files.
6. **WorkManager outbox** – Periodic 15-minute drain of failed/queued messages.

## Permissions

Grant Nearby / Bluetooth / Location (older Android) when prompted so Nearby can start.

## Build

Same GitHub Actions flow: upload ZIP + workflow YAML, run Actions, download PeerTool-debug-APK.

## Honest limits

- WebRTC will not connect internet peers without you configuring a signaling endpoint.
- Camera-based QR *scan* is not included; paste payload works.
- Not a Signal-protocol ratchet; identity + AEAD only.
- Force-stopped apps need a manual open before WorkManager runs again.
